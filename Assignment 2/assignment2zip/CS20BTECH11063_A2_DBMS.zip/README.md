# DBMS 1 Assignment 2
## Tanmay Garg CS20BTECH11063

### Q1
```
sqlite> .open assignment2.db
sqlite> .read q1_query.sql
```
Output is given in q1_op.csv

### Q2
```
sqlite> .open q2_db.db
sqlite> .read q2_query.sql
```
Output is given in q2_op.csv

### Q3
```
sqlite> .open assignment2.db
sqlite> .read q3_query.sql
```
Output is given in q3_op.csv

### Q4
```
sqlite> .open q4_db.db
sqlite> .read q4_query.sql
```
Output is given in q4__op.csv